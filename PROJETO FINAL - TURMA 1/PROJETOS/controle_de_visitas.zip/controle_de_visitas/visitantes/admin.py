from django.contrib import admin

# Register your models here.
from .models import Visita

@admin.register(Visita)
class VisitaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'horario', 'contato')
    list_filter = ('horario',)
    search_fields = ('nome', 'contato')
