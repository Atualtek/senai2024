from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('listar', views.listar_visitas, name='listar_visitas'),
    path('historico/', views.historico_visitas, name='historico_visitas'),
    path('agendar/', views.agendar_visita, name='agendar_visita'),
    path('remover/<int:visita_id>/', views.remover_visita, name='remover_visita'),
]