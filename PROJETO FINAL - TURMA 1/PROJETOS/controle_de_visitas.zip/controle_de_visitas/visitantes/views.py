from django.shortcuts import render, redirect
from .models import Visita
from django.contrib import messages
from datetime import datetime, timedelta, date

# Horários disponíveis
HORARIOS = [
    datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)
    for h in range(9, 21) for m in (0, 30)
]

def home(request):
    hoje = date.today()
    visitas_hoje = Visita.objects.filter(horario__date=hoje).order_by('horario')  # Apenas visitas de hoje
    return render(request, 'visitantes/home.html', {'visitas_hoje': visitas_hoje})

def listar_visitas(request):
    hoje = date.today()  # Data atual
    visitas_hoje = Visita.objects.filter(horario__date=hoje).order_by('horario')  # Agendamentos do dia
    visitas_historico = Visita.objects.exclude(horario__date=hoje).order_by('-horario')  # Visitas passadas
    return render(
        request, 
        'visitantes/listar_visitas.html', 
        {'visitas_hoje': visitas_hoje, 'visitas_historico': visitas_historico}
    )

def agendar_visita(request):
    if request.method == 'POST':
        nome = request.POST['nome']
        contato = request.POST['contato']
        horario = request.POST['horario']

        try:
            horario = datetime.strptime(horario, '%Y-%m-%d %H:%M')

            # Verifica se já há 2 visitas no horário selecionado
            visitas_no_horario = Visita.objects.filter(horario=horario).count()
            if visitas_no_horario >= 2:
                messages.error(request, "Horário já possui duas visitas agendadas. Escolha outro horário.")
                return redirect('agendar_visita')

            Visita.objects.create(nome=nome, contato=contato, horario=horario)
            messages.success(request, "Visita agendada com sucesso.")
            return redirect('home')
        except Exception as e:
            messages.error(request, f"Erro ao agendar visita: {e}")
            return redirect('agendar_visita')

    # Mostra apenas horários disponíveis com menos de 2 visitas
    horarios_disponiveis = [
        h for h in HORARIOS if Visita.objects.filter(horario=h).count() < 2
    ]
    return render(request, 'visitantes/agendar_visita.html', {'horarios': horarios_disponiveis})

def remover_visita(request, visita_id):
    visita = Visita.objects.get(id=visita_id)
    visita.delete()
    messages.success(request, "Visita removida com sucesso.")
    return redirect('listar_visitas')

def historico_visitas(request):
    hoje = date.today()
    visitas_historico = Visita.objects.exclude(horario__date=hoje).order_by('-horario')
    return render(request, 'visitantes/historico_visitas.html', {'visitas_historico': visitas_historico})