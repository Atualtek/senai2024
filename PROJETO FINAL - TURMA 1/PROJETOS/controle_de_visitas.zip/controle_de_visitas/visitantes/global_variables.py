from datetime import datetime

def current_year(request):
    return {'current_year': datetime.now().year}

def current_year(request):
    return {
        'current_year': datetime.now().year,
        'now' : datetime.now(),
     }

def paciente(request):
    return {'paciente': "NOME DO PACIENTE"}

